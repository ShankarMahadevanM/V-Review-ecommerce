const express = require('express');
const bodyParser = require('body-parser');
const User = require('./model');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static('public')); // Serve static files (e.g., login.html)

// Serve the login page
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/login.html');
});
app.post('/', async (req, res) => {
  const { email, password } = req.body;

  try {
    // Find user by email
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Check if password matches
    if (user.password !== password) {
      return res.status(401).json({ message: 'Invalid password' });
    }
    else
    {
      res.sendFile(__dirname + '/index.html');
    }

    // Authentication successful
    
  } catch (error) {
    console.error('Error during login:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});
app.get('/signup', (req, res) => {
  res.sendFile(__dirname + '/signup.html');
});




app.get('/index', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

app.get('/products', (req, res) => {
  res.sendFile(__dirname + '/products.html');
});

app.get('/Pooling', (req, res) => {
  res.sendFile(__dirname + '/Pooling.html');
});
app.get('/gamingconsoles', (req, res) => {
  res.sendFile(__dirname + '/gamingconsole.html');
});
app.get('/headphones', (req, res) => {
  res.sendFile(__dirname + '/headphones.html');
});
app.get('/laptops', (req, res) => {
  res.sendFile(__dirname + '/laptops.html');
});
app.get('/powerbanks', (req, res) => {
  res.sendFile(__dirname + '/powerbanks.html');
});
app.get('/smartchargers', (req, res) => {
  res.sendFile(__dirname + '/smartchargers.html');
});
app.get('/smartwatch', (req, res) => {
  res.sendFile(__dirname + '/smartwatch.html');
});
app.get('/wifi', (req, res) => {
  res.sendFile(__dirname + '/wifi.html');
});

app.get('/headphones', (req, res) => {
  res.sendFile(__dirname + '/headphones.html');
});
app.get('/services', (req, res) => {
  res.sendFile(__dirname + '/Services and E-waste.html');
});
app.get('/smartspeakers', (req, res) => {
  res.sendFile(__dirname + '/smartspeakers.html');
});









// Handle form submission
// app.post('/', (req, res) => {
//   const { username, password } = req.body;

//   // Authenticate user (you would typically hash the password and compare)
//   User.findOne({ username, password }, (err, user) => {
//     if (err) {
//       console.error(err);
//       return res.status(500).send('Internal Server Error');
//     }

//     if (!user) {
//       return res.send('Invalid username or password');
//     }

//     res.send('Login successful');
//   });
// });

app.post('/signup',async(req,res)=>{
  const data={
    email:req.body.email,
    username:req.body.username,
    password:req.body.password
  }
  let r=await User.insertMany([data]);
  console.log(r)
  res.sendFile(__dirname + '/index.html');

})

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
