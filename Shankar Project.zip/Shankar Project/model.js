const mongoose = require('mongoose');

// Database connection configuration
mongoose.connect('mongodb://localhost:27017/mydatabase', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

// User model
const User = mongoose.model('User', {
  email: { type: String, required: true },
  username: { type: String, required: true },
  password: { type: String, required: true },
});

module.exports = User;
